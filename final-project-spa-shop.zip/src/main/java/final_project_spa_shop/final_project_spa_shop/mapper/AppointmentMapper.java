package final_project_spa_shop.final_project_spa_shop.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import final_project_spa_shop.final_project_spa_shop.dto.request.AppointmentRequest;
import final_project_spa_shop.final_project_spa_shop.dto.respone.AppointmentResponse;
import final_project_spa_shop.final_project_spa_shop.entity.AppointmentEntity;

@Mapper(componentModel = "spring")
public interface AppointmentMapper {
	@Mapping(target = "customer",source = "customer.fullName")
	@Mapping(target = "phoneNumber",source = "customer.phoneNumber")
	@Mapping(target = "employee",source = "employee.fullName")
	@Mapping(target = "employeeID",source = "employee.id")
	AppointmentResponse toAppointmentResponse(AppointmentEntity entity);
	@Mapping (target = "customer",ignore = true)
	@Mapping (target = "services",ignore = true)
	@Mapping (target = "employee",ignore = true)
	AppointmentEntity toAppointmentEntity(AppointmentRequest request);
}
