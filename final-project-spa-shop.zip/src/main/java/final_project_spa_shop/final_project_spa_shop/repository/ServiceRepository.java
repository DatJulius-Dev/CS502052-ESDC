package final_project_spa_shop.final_project_spa_shop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import final_project_spa_shop.final_project_spa_shop.entity.ServiceEntity;
import java.util.List;


@Repository
public interface ServiceRepository extends JpaRepository<ServiceEntity,Long>{
	List<ServiceEntity> findByStatusIsTrueAndStockGreaterThan(long stock);
}
