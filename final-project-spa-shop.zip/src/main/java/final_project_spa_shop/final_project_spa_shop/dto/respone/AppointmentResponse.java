package final_project_spa_shop.final_project_spa_shop.dto.respone;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

import final_project_spa_shop.final_project_spa_shop.entity.ServiceEntity;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
	
@FieldDefaults(level = AccessLevel.PRIVATE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentResponse {
	long id;
	String employee;
	String employeeID;
	String customer;
	String phoneNumber;
	LocalDate date;
	LocalTime time;
	Set<ServiceEntity> services;
	String status;
}