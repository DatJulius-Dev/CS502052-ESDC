package final_project_spa_shop.final_project_spa_shop.dto.request;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

import jakarta.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentRequest {
	long id;
	long employee;
	long customer;
	LocalDate date;
	LocalTime time;
	Set<Long> services;
	@Pattern(regexp = "ACCEPT|REJECT|WAITING")
	String status = "WAITING";
}