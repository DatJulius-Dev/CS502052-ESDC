package final_project_spa_shop.final_project_spa_shop.dto.request;

import java.time.LocalDate;

import org.springframework.data.domain.Sort;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class PageDTO {
	int page = 0;
	int pageSize = 10;
	Sort.Direction sort = Sort.Direction.ASC;
	String sortByColumn = "id";
	LocalDate date;
}
