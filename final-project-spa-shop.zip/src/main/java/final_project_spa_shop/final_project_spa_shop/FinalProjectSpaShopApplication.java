package final_project_spa_shop.final_project_spa_shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProjectSpaShopApplication {
	public static void main(String[] args) {
		SpringApplication.run(FinalProjectSpaShopApplication.class, args);
	}

}
