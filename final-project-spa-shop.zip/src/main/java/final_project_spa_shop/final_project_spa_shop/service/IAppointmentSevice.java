package final_project_spa_shop.final_project_spa_shop.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Pageable;

import final_project_spa_shop.final_project_spa_shop.dto.request.AppointmentRequest;
import final_project_spa_shop.final_project_spa_shop.dto.respone.AppointmentResponse;

public interface IAppointmentSevice extends IService<AppointmentResponse, AppointmentRequest> {
	public List<AppointmentResponse> getAllByCustomerID(long id);

	public AppointmentResponse reject(long id);

	public AppointmentResponse accept(long id,AppointmentRequest appointmentRequest);

	public AppointmentResponse findById(long id);

	public int getTotalPage(Pageable pageable, LocalDate date);

	public List<AppointmentResponse> getByPage(Pageable pageable, LocalDate date);

	public List<AppointmentResponse> myAppointment();

}
