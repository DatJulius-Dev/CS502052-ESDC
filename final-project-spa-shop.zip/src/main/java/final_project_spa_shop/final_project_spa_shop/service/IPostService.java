package final_project_spa_shop.final_project_spa_shop.service;

import final_project_spa_shop.final_project_spa_shop.dto.request.PostRequest;
import final_project_spa_shop.final_project_spa_shop.dto.respone.PostResponse;

public interface IPostService extends IService<PostResponse, PostRequest>{
}
