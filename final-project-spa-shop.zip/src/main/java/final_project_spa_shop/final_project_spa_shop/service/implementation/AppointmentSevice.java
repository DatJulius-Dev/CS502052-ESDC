package final_project_spa_shop.final_project_spa_shop.service.implementation;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import final_project_spa_shop.final_project_spa_shop.dto.request.AppointmentRequest;
import final_project_spa_shop.final_project_spa_shop.dto.respone.AppointmentResponse;
import final_project_spa_shop.final_project_spa_shop.entity.AppointmentEntity;
import final_project_spa_shop.final_project_spa_shop.entity.ServiceEntity;
import final_project_spa_shop.final_project_spa_shop.exception.ErrorCode;
import final_project_spa_shop.final_project_spa_shop.mapper.AppointmentMapper;
import final_project_spa_shop.final_project_spa_shop.repository.AppointmentRepository;
import final_project_spa_shop.final_project_spa_shop.repository.CustomerRepository;
import final_project_spa_shop.final_project_spa_shop.repository.EmployeeRepository;
import final_project_spa_shop.final_project_spa_shop.repository.ServiceRepository;
import final_project_spa_shop.final_project_spa_shop.service.IAppointmentSevice;
import jakarta.persistence.EntityNotFoundException;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
public class AppointmentSevice implements IAppointmentSevice {
	AppointmentRepository appointmentRepo;
	CustomerRepository customerRepo;
	EmployeeRepository employeeRepository;
	ServiceRepository serviceRepository;
	AppointmentMapper appointmentMapper;

	@Override
	public List<AppointmentResponse> getAll() {
		return appointmentRepo.findAll().stream().map((x) -> {
			Set<String> services = new HashSet<>(x.getServices().stream().map(ServiceEntity::getName).toList());
			AppointmentResponse appointmentResponse = appointmentMapper.toAppointmentResponse(x);
			return appointmentResponse;
		}).toList();
	}

	@Override
	public List<AppointmentResponse> getByPage(Pageable pageable, LocalDate date) {
		if (date == null) {
			return appointmentRepo.findAll(pageable).getContent().stream().map(appointmentMapper::toAppointmentResponse)
					.toList();
		}
		return appointmentRepo.findByDate(date, pageable).getContent().stream()
				.map(appointmentMapper::toAppointmentResponse).toList();
	}

	@Override
	public int getTotalPage(Pageable pageable, LocalDate date) {
		if (date == null) {
			return appointmentRepo.findAll(pageable).getTotalPages();
		}
		return appointmentRepo.findByDate(date, pageable).getTotalPages();
	}

	@Override
	public AppointmentResponse delete(long id) {
		AppointmentEntity appointmentEntity = appointmentRepo.findById(id)
				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_APPOINTMENT.name()));
		appointmentRepo.deleteById(id);
		return appointmentMapper.toAppointmentResponse(appointmentEntity);
	}

	@Override
	public List<AppointmentResponse> getAllByCustomerID(long id) {
		return appointmentRepo.findByCustomerId(id).stream().map(appointmentMapper::toAppointmentResponse).toList();
	}

	@Override
	public List<AppointmentResponse> myAppointment() {
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		return appointmentRepo.findByCustomerAccountUsername(username).stream().map((x) -> {
			Set<String> services = new HashSet<>(x.getServices().stream().map(ServiceEntity::getName).toList());
			AppointmentResponse appointmentResponse = appointmentMapper.toAppointmentResponse(x);
			return appointmentResponse;
		}).toList();
	}

	@Override
	public AppointmentResponse reject(long id) {
		AppointmentEntity appointmentEntity = appointmentRepo.findById(id)
				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_APPOINTMENT.name()));
		appointmentEntity.setStatus("REJECT");
		return appointmentMapper.toAppointmentResponse(appointmentRepo.save(appointmentEntity));
	}

	@Override
	public AppointmentResponse accept(long id, AppointmentRequest appointmentRequest) {
		AppointmentEntity appointmentEntity = appointmentRepo.findById(id)
				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_APPOINTMENT.name()));
		appointmentEntity.setStatus("ACCEPT");
		Set<ServiceEntity> services = appointmentEntity.getServices();
		services.stream().forEach((service) -> {
			if (service.getStock() <= 5)
				throw new RuntimeException(ErrorCode.OUT_STOCK_SERVICE.name());
			service.setStock(service.getStock() - 1);
			serviceRepository.save(service);
		});
		appointmentEntity.setEmployee(employeeRepository.findById(appointmentRequest.getEmployee())
				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_EMPLOYEE.name())));
		return appointmentMapper.toAppointmentResponse(appointmentRepo.save(appointmentEntity));
	}

	@Override
	public AppointmentResponse save(AppointmentRequest request) {
		LocalDate date = request.getDate();
		long numAppointment = appointmentRepo.countByDate(date);
		if(numAppointment>50) {
			throw new RuntimeException(ErrorCode.MAXIMUM_APPOINTMENT.name());
		}
		if(appointmentRepo.findByCustomerIdAndDate(request.getCustomer(), date).isPresent()) {
			throw new RuntimeException(ErrorCode.DUPLICATE_APPOINTMENT.name());
		}
		AppointmentEntity entity = appointmentMapper.toAppointmentEntity(request);
		long id = entity.getId();
		if (id != 0)
			appointmentRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("INVALID_APPOINTMENT"));
		entity.setCustomer(customerRepo.findById(request.getCustomer())
				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_CUSTOMER.getMessage())));
		entity.setServices(new HashSet<ServiceEntity>(request.getServices().stream().map((x) -> {
			return serviceRepository.findById(x)
					.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_SERVICE.name()));
		}).toList()));
		
		AppointmentResponse appointmentResponse = appointmentMapper.toAppointmentResponse(appointmentRepo.save(entity));
		return appointmentResponse;
	}

	@Override
	public AppointmentResponse findById(long id) {
		AppointmentEntity appointmentEntity = appointmentRepo.findById(id)
				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_APPOINTMENT.name()));
		AppointmentResponse appointmentResponse = appointmentMapper.toAppointmentResponse(appointmentEntity);
//		appointmentResponse.setServices(
//				new HashSet<>(appointmentEntity.getServices().stream().map(ServiceEntity::getName).toList()));
		return appointmentResponse;
	}

//	@Override
//	public PaginationResponse getTotalPage() {
//		return new PaginationResponse((int)Math.ceil(1.0*appointmentRepo.count()/5));
//	}
//	@Override
//	public PaginationResponse getTotalPageToday() {
//		return new PaginationResponse((int)Math.ceil(1.0*appointmentRepo.countByDate(LocalDate.now())/5));
//	}
//	@Override
//	public PaginationResponse getTotalPageTomorow() {
//		return new PaginationResponse((int)Math.ceil(1.0*appointmentRepo.countByDate(LocalDate.now().plusDays(1))/5));
//	}

}

//	@Override
//	public AppointmentResponse save(Date date) {
//		String username = SecurityContextHolder.getContext().getAuthentication().getName();
//		CustomerEntity customerEntity = customerRepo.findByAccountUsername(username)
//				.orElseThrow(() -> new RuntimeException(ErrorCode.INVALID_CUSTOMER.name()));
//		AppointmentRequest request = new AppointmentRequest();
//		request.setDate(date);
//		request.setCustomerID(customerEntity.getId());
//		return save(request);
//	}
