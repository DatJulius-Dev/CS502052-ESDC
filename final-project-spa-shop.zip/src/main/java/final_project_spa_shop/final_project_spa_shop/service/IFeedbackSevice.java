package final_project_spa_shop.final_project_spa_shop.service;

import final_project_spa_shop.final_project_spa_shop.dto.request.FeedbackRequest;
import final_project_spa_shop.final_project_spa_shop.dto.respone.FeedbackResponse;

public interface IFeedbackSevice extends IService<FeedbackResponse, FeedbackRequest> {
}
