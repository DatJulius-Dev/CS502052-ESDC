package final_project_spa_shop.final_project_spa_shop.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
@Entity
@Table(name ="employee")
public class EmployeeEntity extends ProfileEntity{
	
}
