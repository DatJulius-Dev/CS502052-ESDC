package final_project_spa_shop.final_project_spa_shop.entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "appointment")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AppointmentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long id;
	@ManyToOne
	@JoinColumn(name = "employee_id")
	EmployeeEntity employee;
	@ManyToOne
	@JoinColumn(name = "customer_id")
	CustomerEntity customer;
	LocalDate date;
	LocalTime time;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "appointment_service", 
	joinColumns = @JoinColumn(name = "appointment_id"),
	inverseJoinColumns = @JoinColumn(name = "service_id"))
	Set<ServiceEntity> services;
	String status;
}
