const renderAppointment = function (appointments) {
    container = $("#appointmentContainer");
    let html = ""
    appointments.forEach((appointment, index) => {
        operate = `<button  class="btn btn-danger btn-sm" onclick="cancelAppointment(${appointment.id})">Hủy</button> `
        if (appointment.status != "WAITING")
            operate = ""
        let services = ""
        appointment.services.forEach((x) => {
            services += `<div>${x.name}</div>`
        })

        html += `   <tr>
                        <td>${index + 1}</td>
                        <td>${appointment.date}</td>
                        <td>${appointment.time}</td>
                        <td>${services}</td>
                        <td>${appointment.status}</td>
                        <td>
                            ${operate}
                        </td>
                    </tr>
        `;
    });
    container.html(html);
}
const cancelAppointment = async function (appointmentID) {
    console.log(1)
    userConfirm = confirm("Bạn có chắc muốn hủy lịch hẹn ?");
    if (userConfirm) {
        let response = await fetch(`/appointment/${appointmentID}`, {
            method: "DELETE",
        })
        if (response.ok) {
            alert("Hủy lịch hẹn thành công")
            await renderData()
        }
        else {
            alert("Thao tác thất bại")

        }
        await renderData()
    }
}
async function renderData() {
    await fetchData("/appointment/myAppointment", (apiResponse) => {
        if (!apiResponse.success) {
            throw new Error(apiResponse.message)
        }
        renderAppointment(apiResponse.result);
    })

}
const renderListServices = function (services) {
    container = $("#listService");
    let html = ""
    services.forEach((service) => {
        html += ` <div class="form-check">
                    <input type="checkbox" id="service-${service.id}" class="form-check-input"  name="services" value="${service.id}">
                    <label class="form-check-label" for="service-${service.id}">${service.name}</label>
                </div>
        `;
    });
    if (html == "") {
        html = "Hiện tại chúng tôi không còn dịch vụ. Chúng tôi xin lỗi vì sự bất tiện này"
    }
    container.html(html);

}
