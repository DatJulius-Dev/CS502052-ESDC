const renderAppointment = function (appointment) {
    const container = $("#appointmentContainer");
    const html = `
    
<div class="appointment container my-4 p-4 border rounded shadow-sm bg-light">
    
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Hóa đơn:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="#${appointment.id}" readonly>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Tên khách hàng:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="${appointment.customerName}" readonly>
        </div>
    </div>
    
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Mã khách hàng:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="${appointment.customerID}" readonly>
        </div>
    </div>
    
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Ngày:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="${appointment.date}" readonly>
        </div>
    </div>
    
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Dịch vụ:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="${Array.from(appointment.services).join(', ')}" readonly>
        </div>
    </div>
    
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Tổng chi phí:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="${appointment.initalCost * 1000} VNĐ" readonly>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Giảm giá:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control" value="-${appointment.discount * 1000} VNĐ" readonly>
        </div>
    </div>
    
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"><strong>Thành tiền:</strong></label>
        <div class="col-sm-8">
            <input type="text" class="form-control font-weight-bold" value="${appointment.cost * 1000} VND" readonly>
        </div>
    </div>
</div>
    `;
    container.html(html);
    $("button[type='submit']").html(`PAY ${appointment.cost * 1000} VND`)
};

const renderData = async function (id) {
    await fetchData("/appointment/" + id, (apiResponse) => {
        if (!apiResponse.success) {
            throw new Error(apiResponse.message)
        }
        renderAppointment(apiResponse.result);

    })
}

