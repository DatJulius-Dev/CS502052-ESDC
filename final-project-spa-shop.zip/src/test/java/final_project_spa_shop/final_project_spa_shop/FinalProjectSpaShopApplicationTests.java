package final_project_spa_shop.final_project_spa_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectSpaShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
